
# L2Outs
## Name: default
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/tn-common/l2out-default
### Externally Managed By: 
### LC Owner: local
### Last Modified: 2022-11-17T15:49:20.367+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner:
#### Key: 
#### Tag: 
### Status: 
### Target DSCP: unspecified
### UID: 0
### User Domain: all