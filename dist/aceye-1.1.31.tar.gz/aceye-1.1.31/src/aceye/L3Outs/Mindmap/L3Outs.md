
# L3Outs
## default
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-common/out-default
### UID: 0
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: 
### User Domain: all
### Owner
#### Key: 
#### Tag: 
### Priority: 
### Enforce Route Control: export
### Target DSCP: unspecified
### Modified Timestamp: 2022-11-17T15:49:25.041+00:00
## Heroes_external_corporate
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-Heroes/out-Heroes_external_corporate
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: :all:
### Owner
#### Key: 
#### Tag: 
### Priority: 
### Enforce Route Control: export
### Target DSCP: unspecified
### Modified Timestamp: 2022-11-17T18:22:49.779+00:00