
# Spine Switch Profiles
## Name: default
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/spprof-default
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T15:49:20.955+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 0
### User Domain: all