
# Application Profiles
## default
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-common/ap-default
### UID: 0
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: all
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Modified Timestamp: 2022-11-17T15:49:20.367+00:00
## access
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-infra/ap-access
### UID: 0
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: all
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Modified Timestamp: 2022-11-17T15:49:26.901+00:00
## ave-ctrl
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-infra/ap-ave-ctrl
### UID: 0
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: all
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Modified Timestamp: 2022-11-17T15:49:26.901+00:00
## INTERNET_NAT_shapping_APP
### Alias: 
### Description: Tenant Created Using Ansible
### Status: 
### DN: uni/tn-ab/ap-INTERNET_NAT_shapping_APP
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: :all:
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Modified Timestamp: 2022-11-17T15:53:59.530+00:00
## TEST_GK_VERITAS
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-TEST_GK/ap-TEST_GK_VERITAS
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: :all:
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Modified Timestamp: 2022-11-17T16:03:22.886+00:00
## ap_blue_web
### Alias: 
### Description: app profile blue web
### Status: 
### DN: uni/tn-blue/ap-ap_blue_web
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: :all:
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Modified Timestamp: 2022-11-17T16:12:34.035+00:00
## ap_blue_db
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-blue/ap-ap_blue_db
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: :all:
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Modified Timestamp: 2022-11-17T16:12:37.109+00:00
## ap_green_web
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-green/ap-ap_green_web
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: :all:
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Modified Timestamp: 2022-11-17T16:12:40.171+00:00
## ap_green_db
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-green/ap-ap_green_db
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: :all:
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Modified Timestamp: 2022-11-17T16:12:43.164+00:00
## GOATS_APP
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-S2TBK_HOLDINGS-TN/ap-GOATS_APP
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: :all:
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Modified Timestamp: 2022-11-17T16:24:28.241+00:00
## Save_The_Planet
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-Heroes/ap-Save_The_Planet
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: :all:
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Modified Timestamp: 2022-11-17T18:22:49.779+00:00
## Chaos
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-SnV/ap-Chaos
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: :all:
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Modified Timestamp: 2022-11-17T18:22:50.147+00:00
## Power_Up
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-SnV/ap-Power_Up
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: :all:
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Modified Timestamp: 2022-11-17T18:22:50.147+00:00
## Evolution_X
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-SnV/ap-Evolution_X
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: :all:
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Modified Timestamp: 2022-11-17T18:22:50.147+00:00
## Rescue
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-SnV/ap-Rescue
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### User Domain: :all:
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Modified Timestamp: 2022-11-17T18:22:50.147+00:00