# Leaf Switch Profiles
| Name | Name Alias | Annotation | Child Action | Description | DN | Externally Managed By | Local Owner | Last Modified | Monitoring Policy DN | Owner Key | Owner Tag | Status | UID | User Domain |
| ---- | ---------- | ---------- | ------------ | ----------- | -- | --------------------- | ----------- | ------------- | -------------------- | --------- | --------- | ------ | --- | ----------- |
| leaf_2 |  |  |  |  | uni/infra/nprof-leaf_2 |  | local | 2022-11-17T18:22:48.961+00:00 | uni/fabric/monfab-default |  |  |  | 15374 | :all: |
| leaf_1 |  |  |  |  | uni/infra/nprof-leaf_1 |  | local | 2022-11-17T18:22:48.961+00:00 | uni/fabric/monfab-default |  |  |  | 15374 | :all: |
| leafs_1-2 |  |  |  |  | uni/infra/nprof-leafs_1-2 |  | local | 2022-11-17T18:22:48.961+00:00 | uni/fabric/monfab-default |  |  |  | 15374 | :all: |