
# Interface Policies
## Name: ethernet1_1
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-SnV_server2/hports-ethernet1_1-typ-range
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### Type: range
### UID: 15374
### User Domain: :all:
## Name: ethernet1_21
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-Heroes_server1/hports-ethernet1_21-typ-range
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### Type: range
### UID: 15374
### User Domain: :all:
## Name: ethernet1_5-8
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-SnV_FI-1A/hports-ethernet1_5-8-typ-range
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### Type: range
### UID: 15374
### User Domain: :all:
## Name: ethernet1_48
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-SnV_corporate_external/hports-ethernet1_48-typ-range
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### Type: range
### UID: 15374
### User Domain: :all:
## Name: ethernet1_22-24
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-Heroes_phys_act_pass/hports-ethernet1_22-24-typ-range
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### Type: range
### UID: 15374
### User Domain: :all:
## Name: ethernet1_1
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-SnV_server1/hports-ethernet1_1-typ-range
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### Type: range
### UID: 15374
### User Domain: :all:
## Name: ethernet1_2-4
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-SnV_phys_act_pass/hports-ethernet1_2-4-typ-range
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### Type: range
### UID: 15374
### User Domain: :all:
## Name: ethernet1_13-16
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-Heroes_FI-2A/hports-ethernet1_13-16-typ-range
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### Type: range
### UID: 15374
### User Domain: :all:
## Name: ethernet1_9-12
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-SnV_FI-1B/hports-ethernet1_9-12-typ-range
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### Type: range
### UID: 15374
### User Domain: :all:
## Name: ethernet1_17-20
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-Heroes_FI-2B/hports-ethernet1_17-20-typ-range
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### Type: range
### UID: 15374
### User Domain: :all:
## Name: ethernet1_21
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-Heroes_server2/hports-ethernet1_21-typ-range
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### Type: range
### UID: 15374
### User Domain: :all:
## Name: ethernet1_47
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-Heroes_corporate_external/hports-ethernet1_47-typ-range
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### Type: range
### UID: 15374
### User Domain: :all: