
# Fabric Node SSL Certificates
## Name: 
### Name Alias: 
### Authority Key Identifier: 
### Child Action: 
### Data: -----BEGIN CERTIFICATE----- MIIC6TCCAdECAQEwDQYJKoZIhvcNAQELBQAwOTEWMBQGA1UECgwNQ2lzY28gU3lz dGVtczEfMB0GA1UEAwwWQ2lzY28gTWFudWZhY3R1cmluZyBDQTAgFw0yMDA5MjEy MTEyNTFaGA8yMDY1MDczMTIxMTI1MVowOjEQMA4GA1UEAwwHVEVQLTEtMTEmMCQG A1UEBRMdUElEOkFQSUMtU0VSVkVSLUwxIFNOOlRFUC0xLTEwggEiMA0GCSqGSIb3 DQEBAQUAA4IBDwAwggEKAoIBAQCmjE7U/rs41dLfKZpSD/WvFQKx8K26XMDHOh0g asEmspAkvNwNhIwCQz18KQMK9SiYbzCSx0H38t85eQUCwsL+WxFtYRGibdwS0LeH xaGfB6sgxQ950C1K1tn9RT3RSahtOPl+eduSS62dvaBbj758S9rMNcYpE+lqFZie hq/mfeQMJhXVf+f1oMaLlWiYkJEfQeppB9lc3P5WygZRPpFGfuR4kaGlhzSzxnoT IN3fra0y2NKcnJrLnTo5t19/JiFyS5DNsGXAAIJuTJO/K98S9o66g3d7/snpwlNG swjsUZbhDlRRA6StMX2D0KKU+5T3U8NRGq5k8Bqu8gKsdNMRAgMBAAEwDQYJKoZI hvcNAQELBQADggEBADuh4XswxQne+C7iWOhNJgIOdKLgfgBCDQm77EtWzBU+hQMZ PjKzGy8Sr+3vAG4OCHUoAKldM2uWz157/3jEbd5mbelrR1JZigWsF1uXHW+CHZuj tWjs+DYuNyVAENSowTOS3DeYR69hOj6SvP0g93joVBT/Jw+ORLwzDG8n6ylb5MEn H0tQbHGvp4RrtcBIUyQLIwAexYZxHO1m/xF9qoY2FZ9MqHucEYQyqJApFarLzI5L 4sjUCNtArtF+cfQHWCso8nSQ0dDaFi6Xbe+qYIR33irjH+02IuIyoFEadvBHedEi SyIynvQg945WHa4EJDwHLWKFl3OoGrBmCnoVY58= -----END CERTIFICATE----- 
### Description: 
### DN: uni/fabsslcomm/ifmcertnode-1
### Expired Certificate: yes
### Invalid
#### Issuer: no
#### Signing CA For Certificate: no
#### Subject Format: no
### Issuer: /O=Cisco Systems/CN=Cisco Manufacturing CA
### Key Size: 2048
### Local Owner: local
### Message: Local
### Last Modified: 2022-11-17T15:50:33.490+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Node
#### ID: 1
#### Type: Local
### Owner:
#### Key: 
#### Tag: 
### Public Key Algorithm: rsaEncryption
### Serial Number: TEP-1-1
### Signature Algorithm: sha256WithRSAEncryption
### Status: 
### Subject
#### Subject: /CN=TEP-1-1/serialNumber=PID:APIC-SERVER-L1 SN:TEP-1-1
#### Subject Key Identifier: 
### Validate
#### Certificate: yes
#### Validity Not After: 2065-07-31T21:12:51.000+00:00
#### Validity Not Before: 2020-09-21T21:12:51.000+00:00
### Version: 
## Name: 
### Name Alias: 
### Authority Key Identifier: 
### Child Action: 
### Data: -----BEGIN CERTIFICATE----- MIIC8jCCAdoCAgRNMA0GCSqGSIb3DQEBCwUAMDkxFjAUBgNVBAoMDUNpc2NvIFN5 c3RlbXMxHzAdBgNVBAMMFkNpc2NvIE1hbnVmYWN0dXJpbmcgQ0EwIBcNMTkwMjE1 MTk1MTU0WhgPMjA2MzEyMjUxOTUxNTRaMEIxQDA+BgNVBAMMN3NlcmlhbE51bWJl cj1QSUQ6TjlLLUM5Mzk2UFggU046VEVQLTEtMTAxLCBDTj1URVAtMS0xMDEwggEi MA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCygvqn1EC5EN05Rlqs6WuyMXU9 aBW6Kxn6ozBNVf1Wi6RFFaA/AQTiLl0WLxrv8/wF6AgM+GcUDJq1UwP6/J8W/gDU hiQNKohBxkgkS9q5J7wB5JI9RVcOQ8vi3/qsa4d7ky2sW7vMhgo5WisiSAANJJzo SUiHlLHPSwHwAiqjMH9ug8GbpYCQD9vwJXWJU1LDHHLncPtKh9Kg8xoRx7sEadxy JtgYslRJklDuo4TPRIzEY2KoZh+HSThgWg5/qOFaukTEQRf9lrhJVeX7HvB6Lhng TPm6HNPJpZuwz2KnoVK4lBBFLt/zM+cE45h8hZPBzFdkIGY0lZBfrP87mjWpAgMB AAEwDQYJKoZIhvcNAQELBQADggEBADeac3i+rMIAisGzdQGzonfF/7fjv4z6zbEx 25xYZIHmewZXcV1U7Z7SdbWsMk0IgOthopYvLZLpFRk5bwF16oYeyxv3M/fZ8rug 9yhmmEszSCeeN09KJDPyLjsNgHBlBecph90zU+GmEOYBYoIAaH+Z1chJm+f66FDZ EB6m/Ktg5zA+ZSauQEPa73P3HOQ1YKGjnUy6SiK/sMOJ4dOLNqArpBRQH1TiDrzo TYeBui7TmZM52l7wRVg+60B+TgoKZQvNl4z5wOMOPjC8htpCoF6bTy/8n7GpKLV+ rDHjNRw+GCP+O2/j4L+HVoOctNT+ieP+KK0cRJHZoJAqWWioPsc= -----END CERTIFICATE----- 
### Description: 
### DN: uni/fabsslcomm/ifmcertnode-101
### Expired Certificate: yes
### Invalid
#### Issuer: no
#### Signing CA For Certificate: no
#### Subject Format: no
### Issuer: /O=Cisco Systems/CN=Cisco Manufacturing CA
### Key Size: 2048
### Local Owner: local
### Message: Local
### Last Modified: 2022-11-17T17:08:48.596+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Node
#### ID: 101
#### Type: Local
### Owner:
#### Key: 
#### Tag: 
### Public Key Algorithm: rsaEncryption
### Serial Number: TEP-1-101
### Signature Algorithm: sha256WithRSAEncryption
### Status: 
### Subject
#### Subject: /CN=serialNumber=PID:N9K-C9396PX SN:TEP-1-101, CN=TEP-1-101
#### Subject Key Identifier: 
### Validate
#### Certificate: yes
#### Validity Not After: 2063-12-25T19:51:54.000+00:00
#### Validity Not Before: 2019-02-15T19:51:54.000+00:00
### Version: 
## Name: 
### Name Alias: 
### Authority Key Identifier: 
### Child Action: 
### Data: -----BEGIN CERTIFICATE----- MIIC8jCCAdoCAgRPMA0GCSqGSIb3DQEBCwUAMDkxFjAUBgNVBAoMDUNpc2NvIFN5 c3RlbXMxHzAdBgNVBAMMFkNpc2NvIE1hbnVmYWN0dXJpbmcgQ0EwIBcNMTkwMjE1 MTk1MTU1WhgPMjA2MzEyMjUxOTUxNTVaMEIxQDA+BgNVBAMMN3NlcmlhbE51bWJl cj1QSUQ6TjlLLUM5Mzk2UFggU046VEVQLTEtMTAzLCBDTj1URVAtMS0xMDMwggEi MA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCz7OFGPyql5ni+tldDN4csEZgu ssUMt12IPqq9u0UCTU6lrswtXGvbVIJddvMkHrXrQbsE3yMc0nPxIBaolWsRzeV1 +C/LIoiCXnGuA5aVgZgCpP12iTpIPhz2jd9fsK18CPlHSJdC6SOCSmzA4TuqRCjb ejoCd2cfEJ5I8MxrAQ+HjVYfBDzZaItGhWjHUTOwOljcZ2f+c7lRqK6K/btnGMVj 4EsviNOQeYWieULjgjp0GTjdIS8YZu2kB1T6Yk7FKQgOD2ZAS3wtXkWWSnWb5iPi RVNfTFjLjrNY1XU+lX8yhEFkBtIhGJgg4535N2+PA8L6Yo8T+afemWK6dMJ3AgMB AAEwDQYJKoZIhvcNAQELBQADggEBAKyNRoI7uGRSeEd/OrBU2WqCu6G4hNtcez7m oTSbQfCVGvFYf2ci/DceOs73gvYpLf3uaD1qmBq1+N375p5eqfP45wgGCJOdgxNz pQAF3KZx6Jwph2Ef36yaFugUWlgRHuNp48BGc0UA6cwWdKy4XRDYCvkfe340Vcbc rKI4Tmy4Ti4lkvF+Cav2/HgRxKuw5/MTdO9h0CJJqRleIOKs2KBGri+q4itNT9oL 2I9SI8Qes9kBnkfAXfR9mU8EA/xTj86o87Twgw32xktFCsUoUq57AYoynjOjjCTG cO+2/dluuX/XZ5QHf3eiFWdQ2hJGrbR9bCEiKh2I916a6eo5RKc= -----END CERTIFICATE----- 
### Description: 
### DN: uni/fabsslcomm/ifmcertnode-201
### Expired Certificate: yes
### Invalid
#### Issuer: no
#### Signing CA For Certificate: no
#### Subject Format: no
### Issuer: /O=Cisco Systems/CN=Cisco Manufacturing CA
### Key Size: 2048
### Local Owner: local
### Message: Local
### Last Modified: 2022-11-17T18:23:54.266+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Node
#### ID: 201
#### Type: Local
### Owner:
#### Key: 
#### Tag: 
### Public Key Algorithm: rsaEncryption
### Serial Number: TEP-1-103
### Signature Algorithm: sha256WithRSAEncryption
### Status: 
### Subject
#### Subject: /CN=serialNumber=PID:N9K-C9396PX SN:TEP-1-103, CN=TEP-1-103
#### Subject Key Identifier: 
### Validate
#### Certificate: yes
#### Validity Not After: 2063-12-25T19:51:55.000+00:00
#### Validity Not Before: 2019-02-15T19:51:55.000+00:00
### Version: 
## Name: 
### Name Alias: 
### Authority Key Identifier: 
### Child Action: 
### Data: -----BEGIN CERTIFICATE----- MIIC8jCCAdoCAgROMA0GCSqGSIb3DQEBCwUAMDkxFjAUBgNVBAoMDUNpc2NvIFN5 c3RlbXMxHzAdBgNVBAMMFkNpc2NvIE1hbnVmYWN0dXJpbmcgQ0EwIBcNMTkwMjE1 MTk1MTU1WhgPMjA2MzEyMjUxOTUxNTVaMEIxQDA+BgNVBAMMN3NlcmlhbE51bWJl cj1QSUQ6TjlLLUM5Mzk2UFggU046VEVQLTEtMTAyLCBDTj1URVAtMS0xMDIwggEi MA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC9XYjtg0mY6ICrd2qJ4uIEgvVM +iOw5wt9vtgcvhasvmIyfks+lkflti5O1qJtBJiXGKgEZQDYitovbpF9/LIQnXwh DgM2AvUaKzh98+0zNeN+IhDhK77y/uyex+owKVUEZRmQmrIVK6H4jGpNE0CMlfeW aaiSXWw1xBCWHCXtu8IJmqavPtksiBSznXMmzLy63dQDp6bPFLwc1nMVkiCjAQhv A9NylvEX+yuctxGp1+ia3hY3hDBULsjbofnJ5hjOuBZhUQFp2aE7TAAW+xa0cpb6 BD10hBaUkb0AW02tskt0hZk3PHd3SXMNDWB4Z7IJSXNMMQHP+Kg7LRAxnV0RAgMB AAEwDQYJKoZIhvcNAQELBQADggEBAJF/h04DMknr1KNp2QTt5KfPJwdogUoDg1/B fNk1xNIN8dtV6yUctVJQJ9GIuUlnfkGSC+wIuI50LqR58+rkZvUeGZytZ3qeVqQx vL+8TQD+9Vogi/fWmULOhYfnH6l+cA1qu6OhPiDBL/JpCbgYu/+9AZCiT6Hve3F0 8HLh86ToXp8u/k/mXF1NQDzE5KOirgqOJevNeG2Smjn5qYpCn3TO2JoiZJnsyruO I+xbRcKnwRAb9THyNH544DJHY/MKZ519dvCC8FCUzJUYgVuBehApgKJQshSk2smg bM3y0dsK+vkk8sNPygSu/YzDfI7AmhExJD0Gn2PAJikSB15kNbU= -----END CERTIFICATE----- 
### Description: 
### DN: uni/fabsslcomm/ifmcertnode-102
### Expired Certificate: yes
### Invalid
#### Issuer: no
#### Signing CA For Certificate: no
#### Subject Format: no
### Issuer: /O=Cisco Systems/CN=Cisco Manufacturing CA
### Key Size: 2048
### Local Owner: local
### Message: Local
### Last Modified: 2022-11-17T18:24:40.165+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Node
#### ID: 102
#### Type: Local
### Owner:
#### Key: 
#### Tag: 
### Public Key Algorithm: rsaEncryption
### Serial Number: TEP-1-102
### Signature Algorithm: sha256WithRSAEncryption
### Status: 
### Subject
#### Subject: /CN=serialNumber=PID:N9K-C9396PX SN:TEP-1-102, CN=TEP-1-102
#### Subject Key Identifier: 
### Validate
#### Certificate: yes
#### Validity Not After: 2063-12-25T19:51:55.000+00:00
#### Validity Not Before: 2019-02-15T19:51:55.000+00:00
### Version: 