
# Device Packages
## Vendor: CISCO
### Annotation: 
### Audit On Busy: no
### Child Action: 
### DN: uni/infra/mDev-CISCO-CloudMode-1.0
### Externally Managed By: 
### Function Mask: GoThrough,GoTo,L2
### Local Owner: local
### Managed: yes
### Last Modified: 2022-11-17T15:49:19.250+00:00
### Mode: CloudMode
### Monitoring Policy DN: uni/fabric/monfab-default
### Status: 
### UID: 0
### User Domain: all
### Version: 1.0