
# Subnets
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-S2TBK_HOLDINGS-TN/BD-Vlan9_BD/subnet-[10.0.9.253/24]
## Externally Managed By: 
## IP: 10.0.9.253/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: public,shared
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T15:56:14.590+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-S2TBK_HOLDINGS-TN/BD-Vlan18_BD/subnet-[10.0.18.253/24]
## Externally Managed By: 
## IP: 10.0.18.253/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: public,shared
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T15:56:15.422+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-S2TBK_HOLDINGS-TN/BD-Vlan19_BD/subnet-[10.0.19.253/24]
## Externally Managed By: 
## IP: 10.0.19.253/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: public,shared
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T15:56:16.275+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-S2TBK_HOLDINGS-TN/BD-Vlan8_BD/subnet-[10.0.8.253/24]
## Externally Managed By: 
## IP: 10.0.8.253/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: public,shared
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T15:56:28.790+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-TEST_GK/BD-TEST_GK_VLAN201/subnet-[10.133.121.1/24]
## Externally Managed By: 
## IP: 10.133.121.1/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: public
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:03:22.886+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-TEST_GK/BD-TEST_GK_VLAN203/subnet-[10.133.123.1/24]
## Externally Managed By: 
## IP: 10.133.123.1/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: public
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:03:22.886+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-TEST_GK/BD-TEST_GK_VLAN202/subnet-[10.133.122.1/24]
## Externally Managed By: 
## IP: 10.133.122.1/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: public
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:03:22.886+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-S2TBK_HOLDINGS-TN/BD-Vlan81_BD/subnet-[10.0.81.253/24]
## Externally Managed By: 
## IP: 10.0.81.253/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: public,shared
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:23:07.493+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-S2TBK_HOLDINGS-TN/BD-Vlan28_BD/subnet-[10.0.28.253/24]
## Externally Managed By: 
## IP: 10.0.28.253/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: public,shared
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:23:08.334+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-S2TBK_HOLDINGS-TN/BD-Vlan38_BD/subnet-[10.0.38.253/24]
## Externally Managed By: 
## IP: 10.0.38.253/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: public,shared
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:23:09.188+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-S2TBK_HOLDINGS-TN/BD-Vlan68_BD/subnet-[10.0.68.253/24]
## Externally Managed By: 
## IP: 10.0.68.253/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: public,shared
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:23:10.012+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-S2TBK_HOLDINGS-TN/BD-Vlan78_BD/subnet-[10.0.78.253/24]
## Externally Managed By: 
## IP: 10.0.78.253/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: public,shared
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:23:10.843+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-S2TBK_HOLDINGS-TN/BD-Vlan98_BD/subnet-[10.0.98.253/24]
## Externally Managed By: 
## IP: 10.0.98.253/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: public,shared
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:23:11.651+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-S2TBK_HOLDINGS-TN/BD-Vlan88_BD/subnet-[10.0.88.253/24]
## Externally Managed By: 
## IP: 10.0.88.253/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: public,shared
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:23:12.524+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-S2TBK_HOLDINGS-TN/BD-Vlan58_BD/subnet-[10.0.58.253/24]
## Externally Managed By: 
## IP: 10.0.58.253/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: public,shared
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:23:13.377+00:00
## Name: sub_blue_web_1
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: nd
## Debug Message: 
## Description: 
## DN: uni/tn-blue/BD-blue_web/subnet-[10.201.0.1/28]
## Externally Managed By: 
## IP: 10.201.0.1/28
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: private
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:54:38.586+00:00
## Name: sub_blue_web_2
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: nd
## Debug Message: 
## Description: 
## DN: uni/tn-blue/BD-blue_web/subnet-[10.201.1.1/24]
## Externally Managed By: 
## IP: 10.201.1.1/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: private
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:54:41.578+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: nd
## Debug Message: 
## Description: 
## DN: uni/tn-green/BD-green_web/subnet-[10.202.0.2/24]
## Externally Managed By: 
## IP: 10.202.0.2/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: private
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:54:44.642+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: nd
## Debug Message: 
## Description: 
## DN: uni/tn-blue/BD-blue_db/subnet-[10.201.10.1/24]
## Externally Managed By: 
## IP: 10.201.10.1/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: private
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:54:47.695+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: nd
## Debug Message: 
## Description: 
## DN: uni/tn-green/BD-green_db/subnet-[10.202.10.1/24]
## Externally Managed By: 
## IP: 10.202.10.1/24
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: uni/tn-common/monepg-default
## Preferred: no
## Scope: private
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T16:54:50.768+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-Heroes/BD-Hero_Land/subnet-[10.1.120.1/22]
## Externally Managed By: 
## IP: 10.1.120.1/22
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: 
## Preferred: no
## Scope: public
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T18:22:49.605+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: 
## Debug Message: 
## Description: 
## DN: uni/tn-Heroes/BD-Hero_Land/subnet-[192.168.120.1/22]
## Externally Managed By: 
## IP: 192.168.120.1/22
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: 
## Preferred: no
## Scope: private
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T18:22:49.605+00:00
## Name: 
## Alias: 
## Annotation: 
## Child Action: 
## Config Issues: 
## Control: nd
## Debug Message: 
## Description: 
## DN: uni/tn-SnV/BD-antigravity/subnet-[10.2.10.1/23]
## Externally Managed By: 
## IP: 10.2.10.1/23
## IP Data Plane Learning: enabled
## LC Owner: local
## Monitoring Policy DN: 
## Preferred: no
## Scope: private
## Status: 
## UID: 15374
## User Domain: :all:
## Virtual: no
## Last Modified: 2022-11-17T18:22:49.843+00:00