# Tenant Health
| DN | Change | Current | Previous | TW Score | Child Action | Max Severity | Last Modified | Status | Last Updated |
| -- | ------ | ------- | -------- | -------- | ------------ | ------------ | ------------- | ------ | ------------ |
| uni/tn-infra/health | 0 | 100 | 100 | 100 |  | cleared | never |  | 2022-11-17T21:09:51.940+00:00 |
| uni/tn-common/health | 0 | 100 | 100 | 100 |  | cleared | never |  | 2022-11-17T21:09:52.331+00:00 |
| uni/tn-mgmt/health | 0 | 100 | 100 | 100 |  | cleared | never |  | 2022-11-17T21:09:52.686+00:00 |
| uni/tn-ab/health | 0 | 100 | 100 | 100 |  | cleared | never |  | 2022-11-17T21:09:53.051+00:00 |
| uni/tn-S2TBK_HOLDINGS-TN/health | 1 | 97 | 96 | 97 |  | cleared | never |  | 2022-11-17T21:07:34.833+00:00 |
| uni/tn-TEST_GK/health | 0 | 100 | 100 | 100 |  | cleared | never |  | 2022-11-17T21:09:53.753+00:00 |
| uni/tn-blue/health | 0 | 100 | 100 | 100 |  | cleared | never |  | 2022-11-17T21:09:54.130+00:00 |
| uni/tn-green/health | 0 | 100 | 100 | 100 |  | cleared | never |  | 2022-11-17T21:09:54.511+00:00 |
| uni/tn-oneaciapp/health | 0 | 100 | 100 | 100 |  | cleared | never |  | 2022-11-17T21:09:54.896+00:00 |
| uni/tn-Heroes/health | -1 | 94 | 95 | 94 |  | warning | never |  | 2022-11-17T18:41:37.883+00:00 |
| uni/tn-SnV/health | -1 | 94 | 95 | 94 |  | warning | never |  | 2022-11-17T20:01:23.970+00:00 |
| uni/tn-Virg2/health | 0 | 100 | 100 | 100 |  | cleared | never |  | 2022-11-17T21:09:55.968+00:00 |