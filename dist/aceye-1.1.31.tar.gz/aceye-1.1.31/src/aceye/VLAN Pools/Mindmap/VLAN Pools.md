
# VLAN Pools
## Name: GK_VLAN_POOL
### Name Alias: 
### Allocation Mode: static
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/infra/vlanns-[GK_VLAN_POOL]-static
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T16:05:00.258+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: CSR_PHY_STATIC_VLP
### Name Alias: 
### Allocation Mode: dynamic
### Annotation: 
### Child Action: 
### Configuration Issues: missing-encapblk
### Description: Production VLANs
### DN: uni/infra/vlanns-[CSR_PHY_STATIC_VLP]-dynamic
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T16:43:12.033+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: CSR_PHY_STATIC_VLP
### Name Alias: 
### Allocation Mode: static
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: Production VLANs
### DN: uni/infra/vlanns-[CSR_PHY_STATIC_VLP]-static
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T16:54:37.816+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: SnV_general_pool
### Name Alias: 
### Allocation Mode: static
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/infra/vlanns-[SnV_general_pool]-static
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: Heroes_general_pool
### Name Alias: 
### Allocation Mode: static
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/infra/vlanns-[Heroes_general_pool]-static
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all: