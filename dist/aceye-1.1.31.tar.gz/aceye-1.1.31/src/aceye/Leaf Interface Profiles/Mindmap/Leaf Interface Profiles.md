
# Leaf Interface Profiles
## Name: Heroes_FI-2A
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-Heroes_FI-2A
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: SnV_server1
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-SnV_server1
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: Heroes_FI-2B
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-Heroes_FI-2B
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: SnV_server2
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-SnV_server2
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: SnV_phys_act_pass
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-SnV_phys_act_pass
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: SnV_FI-1A
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-SnV_FI-1A
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: Heroes_phys_act_pass
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-Heroes_phys_act_pass
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: Heroes_server1
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-Heroes_server1
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: Heroes_server2
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-Heroes_server2
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: Heroes_corporate_external
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-Heroes_corporate_external
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: SnV_corporate_external
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-SnV_corporate_external
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: SnV_FI-1B
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/accportprof-SnV_FI-1B
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all: