
# Physical Domains
## Name: phys
### Name Alias: 
### Annotation: 
### Child Action: 
### Configuration Issues: 
### DN: uni/phys-phys
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T15:49:20.483+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 0
### User Domain: all
## Name: GK_Phys_Dom
### Name Alias: 
### Annotation: 
### Child Action: 
### Configuration Issues: 
### DN: uni/phys-GK_Phys_Dom
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T16:06:01.909+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: abdou
### Name Alias: 
### Annotation: 
### Child Action: 
### Configuration Issues: 
### DN: uni/phys-abdou
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T17:41:40.994+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: SnV_phys
### Name Alias: 
### Annotation: 
### Child Action: 
### Configuration Issues: 
### DN: uni/phys-SnV_phys
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:49.212+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: Heroes_phys
### Name Alias: 
### Annotation: 
### Child Action: 
### Configuration Issues: 
### DN: uni/phys-Heroes_phys
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:49.408+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all: