# License Entitlements
| Name | Auth Status | Child Action | Count | Description | DN | Local Owner | Last Modified | Status | Tag | Version |
| ---- | ----------- | ------------ | ----- | ----------- | -- | ----------- | ------------- | ------ | ----| ------- |
| ACI_LEAF_BASE_10G | evaluation |  | 2 | ACI Base License for 10/25/40+G Leaf Models: All EX and FX TORs except N9K-C9348GC-FXP | licensecont/entitle-ACI_LEAF_BASE_10G | local | 2022-11-17T18:23:23.502+00:00 |  | regid.2018-01.com.cisco.ACI_LEAF_BASE_10G,1.0_7dbbd5ee-f9d1-4f11-b694-a1e2a5901141 | 1.0 |