
# Fabric Pods
## ID: 1
### Child Action: 
### DN: topology/pod-1
### Local Owner: local
### Last Timestamp: 2022-11-17T15:49:19.851+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Pod Type: physical
### Status: 