# Fabric Pods
| ID | Child Action | DN | Local Owner | Last Modified | Monitoring Policy DN | Pod Type | Status |
| -- | ------------ | -- | ----------- | ------------- | -------------------- | -------- | ------ |
| 1 |  | topology/pod-1 | local | 2022-11-17T15:49:19.851+00:00 | uni/fabric/monfab-default | physical |  |