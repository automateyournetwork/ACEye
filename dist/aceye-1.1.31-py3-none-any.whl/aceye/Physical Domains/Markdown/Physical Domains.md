# Physical Domains
| Name | Name Alias | Annotation | Child Action | Configuration Issues | DN | Externally Managed By | Local Owner | Last Modified | Monitoring Policy DN | Owner Key | Owner Tag | Status | UID | User Domain |
| ---- | ---------- | ---------- | ------------ | -------------------- | -- | --------------------- | ----------- | ------------- | -------------------- | --------- | --------- | ------ | --- | ----------- |
| phys |  |  |  |  | uni/phys-phys |  | local | 2022-11-17T15:49:20.483+00:00 | uni/fabric/monfab-default |  |  |  | 0 | all |
| GK_Phys_Dom |  |  |  |  | uni/phys-GK_Phys_Dom |  | local | 2022-11-17T16:06:01.909+00:00 | uni/fabric/monfab-default |  |  |  | 15374 | :all: |
| abdou |  |  |  |  | uni/phys-abdou |  | local | 2022-11-17T17:41:40.994+00:00 | uni/fabric/monfab-default |  |  |  | 15374 | :all: |
| SnV_phys |  |  |  |  | uni/phys-SnV_phys |  | local | 2022-11-17T18:22:49.212+00:00 | uni/fabric/monfab-default |  |  |  | 15374 | :all: |
| Heroes_phys |  |  |  |  | uni/phys-Heroes_phys |  | local | 2022-11-17T18:22:49.408+00:00 | uni/fabric/monfab-default |  |  |  | 15374 | :all: |