
# Leaf Switch Profiles
## Name: leaf_2
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/nprof-leaf_2
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: leaf_1
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/nprof-leaf_1
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: leafs_1-2
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/nprof-leafs_1-2
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all: