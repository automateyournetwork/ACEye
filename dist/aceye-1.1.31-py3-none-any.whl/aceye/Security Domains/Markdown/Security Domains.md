# Security Domains
| Name | Name Alias | Annotation | Child Action | Description | DN | Externally Managed By | Local Owner | Last Modified | Owner Key | Owner Tag | Restricted RBAC Domain | Status | UID | User Domain |
| ---- | ---------- | ---------- | ------------ | ----------- | -- | --------------------- | ----------- | ------------- | --------- | --------- | ---------------------- | ------ | --- | ----------- |
| common |  |  |  |  | uni/userext/domain-common |  | local | 2022-11-17T15:49:20.766+00:00 |  |  | no |  | 0 | all |
| mgmt |  |  |  |  | uni/userext/domain-mgmt |  | local | 2022-11-17T15:49:20.766+00:00 |  |  | no |  | 0 | all |
| all |  |  |  |  | uni/userext/domain-all |  | local | 2022-11-17T15:49:20.766+00:00 |  |  | no |  | 0 | all |