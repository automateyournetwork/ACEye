
# Security Domains
## Name: common
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/userext/domain-common
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T15:49:20.766+00:00
### Owner
#### Key: 
#### Tag: 
### Restricted RBAC Domain: no
### Status: 
### UID: 0
### User Domain: all
## Name: mgmt
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/userext/domain-mgmt
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T15:49:20.766+00:00
### Owner
#### Key: 
#### Tag: 
### Restricted RBAC Domain: no
### Status: 
### UID: 0
### User Domain: all
## Name: all
### Name Alias: 
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/userext/domain-all
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T15:49:20.766+00:00
### Owner
#### Key: 
#### Tag: 
### Restricted RBAC Domain: no
### Status: 
### UID: 0
### User Domain: all