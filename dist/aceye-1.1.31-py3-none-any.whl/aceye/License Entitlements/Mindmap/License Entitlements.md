
# License Entitlements
## Name: ACI_LEAF_BASE_10G</th>
### Auth Status: evaluation
### Child Action: 
### Count: 2
### Description: ACI Base License for 10/25/40+G Leaf Models: All EX and FX TORs except N9K-C9348GC-FXP
### DN: licensecont/entitle-ACI_LEAF_BASE_10G
### Local Owner: local
### Last Modified: 2022-11-17T18:23:23.502+00:00
### Status: 
### Tag: regid.2018-01.com.cisco.ACI_LEAF_BASE_10G,1.0_7dbbd5ee-f9d1-4f11-b694-a1e2a5901141
### Version: 1.0