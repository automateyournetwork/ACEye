
# Tenants
## infra
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-infra
### UID: 0
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### User Domain: all
### Modified Timestamp: 2022-11-17T15:49:26.901+00:00
## common
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-common
### UID: 0
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### User Domain: all
### Modified Timestamp: 2022-11-17T15:49:20.367+00:00
## mgmt
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-mgmt
### UID: 0
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### User Domain: all
### Modified Timestamp: 2022-11-17T15:49:26.923+00:00
## ab
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-ab
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### User Domain: :all:
### Modified Timestamp: 2022-11-17T15:53:55.329+00:00
## S2TBK_HOLDINGS-TN
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-S2TBK_HOLDINGS-TN
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### User Domain: :all:
### Modified Timestamp: 2022-11-17T15:54:55.136+00:00
## TEST_GK
### Alias: 
### Description: tenant testowy GK
### Status: 
### DN: uni/tn-TEST_GK
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### User Domain: :all:
### Modified Timestamp: 2022-11-17T16:03:22.886+00:00
## blue
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-blue
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### User Domain: :all:
### Modified Timestamp: 2022-11-17T16:12:27.642+00:00
## green
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-green
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### User Domain: :all:
### Modified Timestamp: 2022-11-17T16:12:30.633+00:00
## oneaciapp
### Alias: 
### Description: Try ACI tool demo at https://oneaciapp.talapupa.com
### Status: 
### DN: uni/tn-oneaciapp
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### User Domain: :all:
### Modified Timestamp: 2022-11-17T17:48:48.365+00:00
## Heroes
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-Heroes
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### User Domain: :all:
### Modified Timestamp: 2022-11-17T18:22:49.779+00:00
## SnV
### Alias: 
### Description: 
### Status: 
### DN: uni/tn-SnV
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### User Domain: :all:
### Modified Timestamp: 2022-11-17T18:22:50.147+00:00
## Virg2
### Alias: 
### Description: Tenant Created Using Ansible
### Status: 
### DN: uni/tn-Virg2
### UID: 15374
### Annotation: 
### Child Action: 
### Externally Managed By: 
### Local Owner: local
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### User Domain: :all:
### Modified Timestamp: 2022-11-17T20:41:24.463+00:00