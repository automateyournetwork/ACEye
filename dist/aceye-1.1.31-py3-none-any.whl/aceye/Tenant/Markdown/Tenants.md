# Tenants
| Name | Alias | Description | Status | DN | UID | Annotation | Child Action | Externally Managed By | Local Owner | Monitoring Policy DN | Owner Key | Owner Tag | User Domain | Modified Timestamp |
| ---- | ----- | ----------- | ------ | -- | --- | ---------- | ------------ | -------------- | ----------- | ---------- | --------- | --------- | ----------- | ------------------ |
| infra |  |  |  | uni/tn-infra | 0 |  |  |  | local | uni/tn-common/monepg-default |  |  | all | 2022-11-17T15:49:26.901+00:00 |
| common |  |  |  | uni/tn-common | 0 |  |  |  | local | uni/tn-common/monepg-default |  |  | all | 2022-11-17T15:49:20.367+00:00 |
| mgmt |  |  |  | uni/tn-mgmt | 0 |  |  |  | local | uni/tn-common/monepg-default |  |  | all | 2022-11-17T15:49:26.923+00:00 |
| ab |  |  |  | uni/tn-ab | 15374 |  |  |  | local | uni/tn-common/monepg-default |  |  | :all: | 2022-11-17T15:53:55.329+00:00 |
| S2TBK_HOLDINGS-TN |  |  |  | uni/tn-S2TBK_HOLDINGS-TN | 15374 |  |  |  | local | uni/tn-common/monepg-default |  |  | :all: | 2022-11-17T15:54:55.136+00:00 |
| TEST_GK |  | tenant testowy GK |  | uni/tn-TEST_GK | 15374 |  |  |  | local | uni/tn-common/monepg-default |  |  | :all: | 2022-11-17T16:03:22.886+00:00 |
| blue |  |  |  | uni/tn-blue | 15374 |  |  |  | local | uni/tn-common/monepg-default |  |  | :all: | 2022-11-17T16:12:27.642+00:00 |
| green |  |  |  | uni/tn-green | 15374 |  |  |  | local | uni/tn-common/monepg-default |  |  | :all: | 2022-11-17T16:12:30.633+00:00 |
| oneaciapp |  | Try ACI tool demo at https://oneaciapp.talapupa.com |  | uni/tn-oneaciapp | 15374 |  |  |  | local | uni/tn-common/monepg-default |  |  | :all: | 2022-11-17T17:48:48.365+00:00 |
| Heroes |  |  |  | uni/tn-Heroes | 15374 |  |  |  | local | uni/tn-common/monepg-default |  |  | :all: | 2022-11-17T18:22:49.779+00:00 |
| SnV |  |  |  | uni/tn-SnV | 15374 |  |  |  | local | uni/tn-common/monepg-default |  |  | :all: | 2022-11-17T18:22:50.147+00:00 |
| Virg2 |  | Tenant Created Using Ansible |  | uni/tn-Virg2 | 15374 |  |  |  | local | uni/tn-common/monepg-default |  |  | :all: | 2022-11-17T20:41:24.463+00:00 |