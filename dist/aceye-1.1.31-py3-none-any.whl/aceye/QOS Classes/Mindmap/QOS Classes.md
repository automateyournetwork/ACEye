
# QOS Classes
## Name: 
### Name Alias: 
### Admin: enabled
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/qosinst-default/class-level6
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T15:49:25.666+00:00
### MTU: 9216
### Owner
#### Key: 
#### Tag: 
### Priority: level6
### Status: 
### UID: 0
### User Domain: all
## Name: 
### Name Alias: 
### Admin: enabled
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/qosinst-default/class-level1
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T15:49:25.666+00:00
### MTU: 9216
### Owner
#### Key: 
#### Tag: 
### Priority: level1
### Status: 
### UID: 0
### User Domain: all
## Name: 
### Name Alias: 
### Admin: enabled
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/qosinst-default/class-level3
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T15:49:25.666+00:00
### MTU: 9216
### Owner
#### Key: 
#### Tag: 
### Priority: level3
### Status: 
### UID: 0
### User Domain: all
## Name: 
### Name Alias: 
### Admin: enabled
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/qosinst-default/class-level2
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T15:49:25.666+00:00
### MTU: 9216
### Owner
#### Key: 
#### Tag: 
### Priority: level2
### Status: 
### UID: 0
### User Domain: all
## Name: 
### Name Alias: 
### Admin: enabled
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/qosinst-default/class-level5
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T15:49:25.666+00:00
### MTU: 9216
### Owner
#### Key: 
#### Tag: 
### Priority: level5
### Status: 
### UID: 0
### User Domain: all
## Name: 
### Name Alias: 
### Admin: enabled
### Annotation: 
### Child Action: 
### Description: 
### DN: uni/infra/qosinst-default/class-level4
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T15:49:25.666+00:00
### MTU: 9216
### Owner
#### Key: 
#### Tag: 
### Priority: level4
### Status: 
### UID: 0
### User Domain: all