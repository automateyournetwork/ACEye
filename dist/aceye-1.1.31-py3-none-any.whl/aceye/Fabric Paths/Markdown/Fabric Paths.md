# Fabric Paths
| Node 1 | Node 2 | Child Action | DN | Local Owner | Last Updated | Monitoring Policy DN | Status |
| ------ | ------ | ------------ | -- | ----------- | ------------ | -------------------- | ------ |
| 102 | 101 |  | topology/pod-1/path-102-101 | local | 2022-11-17T18:24:24.100+00:00 | uni/fabric/monfab-default |  |
| 101 | 102 |  | topology/pod-1/path-101-102 | local | 2022-11-17T18:24:24.100+00:00 | uni/fabric/monfab-default |  |