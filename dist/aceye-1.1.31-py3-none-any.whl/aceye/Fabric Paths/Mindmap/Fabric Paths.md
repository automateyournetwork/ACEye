
# Fabric Paths
## DN: topology/pod-1/path-102-101
### Nodes
#### Node 1: 102
#### Node 2: 101
### Child Action: 
### Local Owner: local
### Last Modified: 2022-11-17T18:24:24.100+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Status: 
## DN: topology/pod-1/path-101-102
### Nodes
#### Node 1: 101
#### Node 2: 102
### Child Action: 
### Local Owner: local
### Last Modified: 2022-11-17T18:24:24.100+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Status: 