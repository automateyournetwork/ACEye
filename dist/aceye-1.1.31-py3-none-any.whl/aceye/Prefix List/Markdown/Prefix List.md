# Fabric Nodes
| Annotation | Child Action | Description | DN | Externally Managed By | Local Owner | Last Modified | Name | Name Alias | Status | UID | User Domain |
| ---------- | ------------ | ----------- | -- | --------------------- | ----------- | ------------- | ---- | ---------- | ------ | --- | ----------- |