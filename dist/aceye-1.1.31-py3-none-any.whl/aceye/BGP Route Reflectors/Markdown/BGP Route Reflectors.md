# BGP Route Reflectors
| Name | Name Alias | Annotation | Child Action | Description | DN | Externally Managed By | ID | Local Owner | Last Modified | Monitoring Policy DN | POD ID | Status | UID | User Domain |
| ---- | ---------- | ---------- | ------------ | ----------- | -- | --------------------- | -- | ----------- | ------------- | -------------------- | ------ | ------ | --- | ----------- |