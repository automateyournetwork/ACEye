
# Fabric Membership
## DN: topology/pod-1/node-1/sys/ctrlrfwstatuscont/ctrlrrunning
### Child Action: 
### Description: 
### Internal Label: 72bfb79869cf7edf6ad17c7bb072c16dd45fdbbd
### Local Owner: local
### Last Modified: 2022-11-17T15:51:31.070+00:00
### Mode: normal
### Status: 
### TPM In Use: no
### Timestamp: 2022-11-17T15:51:31.075+00:00
### Type: controller
### Version: 5.2(1g)