
# Aggregate Interfaces
## bond1
### Admin State: up</td>
### Auto Negotiate: on</td>
### Bandwidth: 0</td>
### Child Action: </td>
### Delay: 1</td>
### Description: </td>
### DN: topology/pod-1/node-1/sys/caggr-[po1.1]</td>
### Dot1q Ether Type: 0x8100</td>
### FCOT Channel Number: Channel32</td>
### ID: po1.1</td>
### Inherited Bandwidth: unspecified</td>
### Is Reflective Relay Config Supported: Supported</td>
### Layer: Layer3</td>
### Local Owner: local</td>
### Link Debounce: 100</td>
### Link Log: default</td>
### MDIX: auto</td>
### Medium: broadcast</td>
### Last Modified: 2022-11-17T21:09:19.418+00:00</td>
### Mode: trunk</td>
### Monitoring Policy DN: uni/fabric/monfab-default</td>
### MTU: 0</td>
### Oper State: down</td>
### Path S Description: </td>
### Port T: unknown</td>
### Priority Flow Control: auto</td>
### Reflective Relay Enable: off</td>
### Router MAC: not-applicable</td>
### SNMP Trap State: enable</td>
### Span Mode: not-a-span-dest</td>
### Speed: inherit</td>
### Status: </td>
### Switching State: disabled</td>
### Trunk Log: default</td>
### Usage: discovery</td>
## bond0
### Admin State: up</td>
### Auto Negotiate: on</td>
### Bandwidth: 0</td>
### Child Action: </td>
### Delay: 1</td>
### Description: </td>
### DN: topology/pod-1/node-1/sys/caggr-[po1]</td>
### Dot1q Ether Type: 0x8100</td>
### FCOT Channel Number: Channel32</td>
### ID: po1</td>
### Inherited Bandwidth: unspecified</td>
### Is Reflective Relay Config Supported: Supported</td>
### Layer: Layer3</td>
### Local Owner: local</td>
### Link Debounce: 100</td>
### Link Log: default</td>
### MDIX: auto</td>
### Medium: broadcast</td>
### Last Modified: 2022-11-17T21:09:19.418+00:00</td>
### Mode: trunk</td>
### Monitoring Policy DN: uni/fabric/monfab-default</td>
### MTU: 1500</td>
### Oper State: up</td>
### Path S Description: </td>
### Port T: unknown</td>
### Priority Flow Control: auto</td>
### Reflective Relay Enable: off</td>
### Router MAC: 6A:F6:A9:34:32:30</td>
### SNMP Trap State: enable</td>
### Span Mode: not-a-span-dest</td>
### Speed: inherit</td>
### Status: </td>
### Switching State: disabled</td>
### Trunk Log: default</td>
### Usage: discovery</td>