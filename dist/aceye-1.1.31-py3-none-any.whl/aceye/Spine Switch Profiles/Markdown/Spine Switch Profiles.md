# Spine Switch Profiles
| Name | Name Alias | Annotation | Child Action | Description | DN | Externally Managed By | Local Owner | Last Modified | Monitoring Policy DN | Owner Key | Owner Tag | Status | UID | User Domain |
| ---- | ---------- | ---------- | ------------ | ----------- | -- | --------------------- | ----------- | ------------- | -------------------- | --------- | --------- | ------ | --- | ----------- |
| default |  |  |  |  | uni/infra/spprof-default |  | local | 2022-11-17T15:49:20.955+00:00 | uni/fabric/monfab-default |  |  |  | 0 | all |