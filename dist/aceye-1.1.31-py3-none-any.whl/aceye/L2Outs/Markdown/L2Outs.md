# L2Outs
| Name | Name Alias | Annotation | Child Action | Description | DN | Externally Managed By | LC Owner | Last Modified | Monitoring Policy DN | Owner Key | Owner Tag | Status | Target DSCP | UID | User Domain |
| ---- | ---------- | ---------- | ------------ | ----------- | -- | --------------------- | -------- | ------------- | -------------------- | --------- | --------- | ------ | ----------- | --- | ----------- |
| default |  |  |  |  | uni/tn-common/l2out-default |  | local | 2022-11-17T15:49:20.367+00:00 | uni/tn-common/monepg-default |  |  |  | unspecified | 0 | all |