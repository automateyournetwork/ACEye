
# Contracts
## Name: default
### Name Alias: 
### Access Privilege: USER
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/tn-common/brc-default
### Externally Managed By: 
### Intent: install
### Local Owner: local
### Last Modified: 2022-11-17T15:49:20.367+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Re Evaluate All: no
### Scope: context
### Status: 
### Targer DSCP: unspecified
### UID: 0
### User Domain: all
## Name: VERITAS_Ctr
### Name Alias: 
### Access Privilege: USER
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/tn-TEST_GK/brc-VERITAS_Ctr
### Externally Managed By: 
### Intent: install
### Local Owner: local
### Last Modified: 2022-11-17T16:03:23.034+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Re Evaluate All: no
### Scope: application-profile
### Status: 
### Targer DSCP: unspecified
### UID: 15374
### User Domain: :all:
## Name: web
### Name Alias: 
### Access Privilege: USER
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/tn-common/brc-web
### Externally Managed By: 
### Intent: install
### Local Owner: local
### Last Modified: 2022-11-17T18:22:49.369+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Re Evaluate All: no
### Scope: context
### Status: 
### Targer DSCP: unspecified
### UID: 15374
### User Domain: :all:
## Name: sql
### Name Alias: 
### Access Privilege: USER
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/tn-common/brc-sql
### Externally Managed By: 
### Intent: install
### Local Owner: local
### Last Modified: 2022-11-17T18:22:49.369+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Re Evaluate All: no
### Scope: application-profile
### Status: 
### Targer DSCP: unspecified
### UID: 15374
### User Domain: :all:
## Name: power_up
### Name Alias: 
### Access Privilege: USER
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/tn-common/brc-power_up
### Externally Managed By: 
### Intent: install
### Local Owner: local
### Last Modified: 2022-11-17T18:22:49.369+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Re Evaluate All: no
### Scope: context
### Status: 
### Targer DSCP: unspecified
### UID: 15374
### User Domain: :all:
## Name: web
### Name Alias: 
### Access Privilege: USER
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/tn-SnV/brc-web
### Externally Managed By: 
### Intent: install
### Local Owner: local
### Last Modified: 2022-11-17T18:22:50.147+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Re Evaluate All: no
### Scope: context
### Status: 
### Targer DSCP: unspecified
### UID: 15374
### User Domain: :all:
## Name: database
### Name Alias: 
### Access Privilege: USER
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/tn-SnV/brc-database
### Externally Managed By: 
### Intent: install
### Local Owner: local
### Last Modified: 2022-11-17T18:22:50.147+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Owner
#### Key: 
#### Tag: 
### Priority: unspecified
### Re Evaluate All: no
### Scope: application-profile
### Status: 
### Targer DSCP: unspecified
### UID: 15374
### User Domain: :all: