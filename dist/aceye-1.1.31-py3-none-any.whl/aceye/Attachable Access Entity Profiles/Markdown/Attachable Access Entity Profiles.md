# Attachable Access Entity Profiles
| Name | Name Alias | Allocation Mode | Annotation | Child Action | Configuration Issues | Description | DN | Externally Managed By | Local Owner | Last Modified | Monitoring Policy DN | Owner Key | Owner Tag | Status | UID | User Domain |
| ---- | ---------- | --------------- | ---------- | ------------ | -------------------- | ----------- | -- | --------------------- | ----------- | ------------- | -------------------- | --------- | --------- | ------ | --- | ----------- |
| default |  |  |  |  |  |  | uni/infra/attentp-default |  | local | 2022-11-17T15:49:20.955+00:00 | uni/fabric/monfab-default |  |  |  | 0 | all |
| GK_AAEP |  |  |  |  |  |  | uni/infra/attentp-GK_AAEP |  | local | 2022-11-17T16:05:54.439+00:00 | uni/fabric/monfab-default |  |  |  | 15374 | :all: |
| Heroes_phys |  |  |  |  |  |  | uni/infra/attentp-Heroes_phys |  | local | 2022-11-17T18:22:48.961+00:00 | uni/fabric/monfab-default |  |  |  | 15374 | :all: |
| SnV_corporate_external |  |  |  |  |  |  | uni/infra/attentp-SnV_corporate_external |  | local | 2022-11-17T18:22:48.961+00:00 | uni/fabric/monfab-default |  |  |  | 15374 | :all: |
| SnV_phys |  |  |  |  |  |  | uni/infra/attentp-SnV_phys |  | local | 2022-11-17T18:22:48.961+00:00 | uni/fabric/monfab-default |  |  |  | 15374 | :all: |
| Heroes_corporate_external |  |  |  |  |  |  | uni/infra/attentp-Heroes_corporate_external |  | local | 2022-11-17T18:22:48.961+00:00 | uni/fabric/monfab-default |  |  |  | 15374 | :all: |