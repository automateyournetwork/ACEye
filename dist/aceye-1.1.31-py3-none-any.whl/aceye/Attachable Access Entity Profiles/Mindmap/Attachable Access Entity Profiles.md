
# Attachable Access Entity Profiles
## Name: default
### Name Alias: 
### Allocation Mode: 
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/infra/attentp-default
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T15:49:20.955+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 0
### User Domain: all
## Name: GK_AAEP
### Name Alias: 
### Allocation Mode: 
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/infra/attentp-GK_AAEP
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T16:05:54.439+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: Heroes_phys
### Name Alias: 
### Allocation Mode: 
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/infra/attentp-Heroes_phys
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: SnV_corporate_external
### Name Alias: 
### Allocation Mode: 
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/infra/attentp-SnV_corporate_external
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: SnV_phys
### Name Alias: 
### Allocation Mode: 
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/infra/attentp-SnV_phys
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all:
## Name: Heroes_corporate_external
### Name Alias: 
### Allocation Mode: 
### Annotation: 
### Child Action: 
### Configuration Issues: 
### Description: 
### DN: uni/infra/attentp-Heroes_corporate_external
### Externally Managed By: 
### Local Owner: local
### Last Modified: 2022-11-17T18:22:48.961+00:00
### Monitoring Policy DN: uni/fabric/monfab-default
### Owner
#### Key: 
#### Tag: 
### Status: 
### UID: 15374
### User Domain: :all: