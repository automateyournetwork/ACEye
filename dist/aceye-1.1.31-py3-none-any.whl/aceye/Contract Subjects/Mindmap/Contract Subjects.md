
# Contract Subjects
## Name: default
### Name Alias: 
### Access Privilege: USER
### Annotication: 
### Child Action: 
### Configuration Issues: 
### Match T
#### Consumer: AtleastOne
#### Provider: AtleastOne
### Description: 
### DN: uni/tn-common/oobbrc-default/subj-default
### Externally Managed By: 
### Local Onwer: local
### Last Modified: 2022-11-17T15:49:20.367+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Priority: unspecified
### Reverse Filter Ports: yes
### Status: 
### Target DSCP: unspecified
### UID: 0
### User Domain: all
## Name: default
### Name Alias: 
### Access Privilege: USER
### Annotication: 
### Child Action: 
### Configuration Issues: 
### Match T
#### Consumer: AtleastOne
#### Provider: AtleastOne
### Description: 
### DN: uni/tn-common/brc-default/subj-default
### Externally Managed By: 
### Local Onwer: local
### Last Modified: 2022-11-17T15:49:20.367+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Priority: unspecified
### Reverse Filter Ports: yes
### Status: 
### Target DSCP: unspecified
### UID: 0
### User Domain: all
## Name: VERITAS_ALL_Subj
### Name Alias: 
### Access Privilege: USER
### Annotication: 
### Child Action: 
### Configuration Issues: 
### Match T
#### Consumer: AtleastOne
#### Provider: AtleastOne
### Description: 
### DN: uni/tn-TEST_GK/brc-VERITAS_Ctr/subj-VERITAS_ALL_Subj
### Externally Managed By: 
### Local Onwer: local
### Last Modified: 2022-11-17T16:03:22.886+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Priority: unspecified
### Reverse Filter Ports: yes
### Status: 
### Target DSCP: unspecified
### UID: 15374
### User Domain: :all:
## Name: http
### Name Alias: 
### Access Privilege: USER
### Annotication: 
### Child Action: 
### Configuration Issues: 
### Match T
#### Consumer: AtleastOne
#### Provider: AtleastOne
### Description: 
### DN: uni/tn-common/brc-web/subj-http
### Externally Managed By: 
### Local Onwer: local
### Last Modified: 2022-11-17T18:22:49.369+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Priority: unspecified
### Reverse Filter Ports: yes
### Status: 
### Target DSCP: unspecified
### UID: 15374
### User Domain: :all:
## Name: sql-browser
### Name Alias: 
### Access Privilege: USER
### Annotication: 
### Child Action: 
### Configuration Issues: 
### Match T
#### Consumer: AtleastOne
#### Provider: AtleastOne
### Description: 
### DN: uni/tn-common/brc-sql/subj-sql-browser
### Externally Managed By: 
### Local Onwer: local
### Last Modified: 2022-11-17T18:22:49.369+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Priority: unspecified
### Reverse Filter Ports: yes
### Status: 
### Target DSCP: unspecified
### UID: 15374
### User Domain: :all:
## Name: https
### Name Alias: 
### Access Privilege: USER
### Annotication: 
### Child Action: 
### Configuration Issues: 
### Match T
#### Consumer: AtleastOne
#### Provider: AtleastOne
### Description: 
### DN: uni/tn-common/brc-web/subj-https
### Externally Managed By: 
### Local Onwer: local
### Last Modified: 2022-11-17T18:22:49.369+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Priority: unspecified
### Reverse Filter Ports: yes
### Status: 
### Target DSCP: unspecified
### UID: 15374
### User Domain: :all:
## Name: app_ports
### Name Alias: 
### Access Privilege: USER
### Annotication: 
### Child Action: 
### Configuration Issues: 
### Match T
#### Consumer: AtleastOne
#### Provider: AtleastOne
### Description: 
### DN: uni/tn-common/brc-power_up/subj-app_ports
### Externally Managed By: 
### Local Onwer: local
### Last Modified: 2022-11-17T18:22:49.369+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Priority: unspecified
### Reverse Filter Ports: yes
### Status: 
### Target DSCP: unspecified
### UID: 15374
### User Domain: :all:
## Name: sql-server
### Name Alias: 
### Access Privilege: USER
### Annotication: 
### Child Action: 
### Configuration Issues: 
### Match T
#### Consumer: AtleastOne
#### Provider: AtleastOne
### Description: 
### DN: uni/tn-common/brc-sql/subj-sql-server
### Externally Managed By: 
### Local Onwer: local
### Last Modified: 2022-11-17T18:22:49.369+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Priority: unspecified
### Reverse Filter Ports: yes
### Status: 
### Target DSCP: unspecified
### UID: 15374
### User Domain: :all:
## Name: sql
### Name Alias: 
### Access Privilege: USER
### Annotication: 
### Child Action: 
### Configuration Issues: 
### Match T
#### Consumer: AtleastOne
#### Provider: AtleastOne
### Description: 
### DN: uni/tn-SnV/brc-database/subj-sql
### Externally Managed By: 
### Local Onwer: local
### Last Modified: 2022-11-17T18:22:50.147+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Priority: unspecified
### Reverse Filter Ports: yes
### Status: 
### Target DSCP: unspecified
### UID: 15374
### User Domain: :all:
## Name: http
### Name Alias: 
### Access Privilege: USER
### Annotication: 
### Child Action: 
### Configuration Issues: 
### Match T
#### Consumer: AtleastOne
#### Provider: AtleastOne
### Description: 
### DN: uni/tn-SnV/brc-web/subj-http
### Externally Managed By: 
### Local Onwer: local
### Last Modified: 2022-11-17T18:22:50.147+00:00
### Monitoring Policy DN: uni/tn-common/monepg-default
### Priority: unspecified
### Reverse Filter Ports: yes
### Status: 
### Target DSCP: unspecified
### UID: 15374
### User Domain: :all: