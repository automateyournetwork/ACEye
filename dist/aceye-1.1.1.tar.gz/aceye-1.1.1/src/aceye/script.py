from .aceye import cli
def run():
    cli()